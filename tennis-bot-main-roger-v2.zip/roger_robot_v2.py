"""
roger_robot_v2.py

New file — roger_robot.py is left untouched (it currently holds a
duplicate copy of the Motion class, not hardware setup).

This is what roger_robot.py's name suggests it should contain:
hardware object setup, mirroring rafael_robot.py's role for the
other bot. Keeps this repo's own existing convention for the
motor-mirroring direction fix — Direction.COUNTERCLOCKWISE /
CLOCKWISE on the motor objects — since that's what gyro.py,
touch.py, and drive2.py already use elsewhere in this repo, rather
than mixing in rafael's software-side sign-flip approach.

Port numbers/sensors below are carried over from gyro.py/touch.py/
drive2.py — double check they match your actual current wiring
before trusting this on the mat.
"""

from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Direction, Port

hub = PrimeHub()

left_motor = Motor(Port.A, positive_direction=Direction.COUNTERCLOCKWISE)

right_motor = Motor(Port.E, positive_direction=Direction.CLOCKWISE)

distance_sensor = UltrasonicSensor(Port.F)

touch_sensor = ForceSensor(Port.B)
